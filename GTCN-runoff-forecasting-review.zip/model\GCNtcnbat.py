﻿import math

import torch
import torch.nn.functional as F
from torch import nn
from torch.nn.parameter import Parameter

from .tcn import TemporalConvNet


class GraphConvolution(nn.Module):
    """Batched graph convolution for node features with shape (B, N, F)."""

    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.empty(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.out_features)
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, inputs, adj):
        support = torch.matmul(inputs, self.weight)
        if adj.dim() == 2:
            adj = adj.unsqueeze(0).repeat(inputs.size(0), 1, 1)
        output = torch.bmm(adj, support)
        if self.bias is not None:
            output = output + self.bias
        return output

    def __repr__(self):
        return f"{self.__class__.__name__}({self.in_features} -> {self.out_features})"


class LearnableAdj(nn.Module):
    """Learnable row-normalized adjacency matrix for hydrometeorological variables."""

    def __init__(self, num_vars=6):
        super().__init__()
        self.num_vars = num_vars
        self.raw_adj = nn.Parameter(torch.eye(num_vars) + 0.01 * torch.randn(num_vars, num_vars))

    def forward(self, x):
        return F.softmax(self.raw_adj, dim=-1)


class TCN(nn.Module):
    """Variable-as-node graph-temporal convolutional network (G-TCN).

    The input shape is (B, T, C), where T=22 contains 15 antecedent memory days
    and 7 forecast-aligned positions, and C=6 contains five meteorological
    variables plus runoff.
    """

    def __init__(self, input_size, output_size, num_channels, kernel_size=2,
                 dropout=0.3, emb_dropout=0.1, tied_weights=False):
        super().__init__()

        self.learnable_adj = LearnableAdj(num_vars=6)
        self.gc1 = GraphConvolution(22, input_size)
        self.gc2 = GraphConvolution(input_size, 22)

        self.encoder = nn.Linear(6, input_size)
        self.tcn = TemporalConvNet(input_size, num_channels, kernel_size, dropout=dropout)
        self.decoder = nn.Linear(num_channels[-1], output_size)

        self.att_x = nn.Linear(1, 1)
        self.att_y = nn.Linear(1, 1)
        self.drop = nn.Dropout(emb_dropout)

        self.time_decay = nn.Parameter(torch.tensor(0.1))
        self.memory_days = 15

        if tied_weights:
            if num_channels[-1] != input_size:
                raise ValueError("When tied_weights=True, num_channels[-1] must equal input_size.")
            self.decoder.weight = self.encoder.weight

        self.init_weights()

    def init_weights(self):
        self.encoder.weight.data.normal_(0, 0.01)
        self.decoder.bias.data.fill_(0)
        self.decoder.weight.data.normal_(0, 0.01)

    def forward(self, inputs):
        # TCN temporal branch.
        emb = self.drop(self.encoder(inputs))
        emb = emb.transpose(1, 2)
        enc = self.tcn(emb).transpose(1, 2)
        y = self.decoder(enc)
        y = y[:, :, -1].unsqueeze(-1)

        # GCN variable-interaction branch with learnable time decay.
        batch_size, seq_len, num_vars = inputs.shape
        if seq_len < self.memory_days:
            raise ValueError("input sequence length must be at least memory_days")

        t_decay = torch.arange(self.memory_days, device=inputs.device).float()
        weights = torch.exp(-self.time_decay * (self.memory_days - 1 - t_decay))
        weights = weights / weights.sum()

        decayed_inputs = inputs.clone()
        decayed_inputs[:, :self.memory_days, :] *= weights.view(1, self.memory_days, 1)

        x = decayed_inputs.transpose(1, 2)
        adj = self.learnable_adj(x)
        x = F.relu(self.gc1(x, adj))
        x = self.drop(x)
        x = self.gc2(x, adj)
        x = x.transpose(1, 2)
        x = x[:, :, -1].unsqueeze(-1)

        # Attention fusion between graph and temporal pathways.
        att = torch.softmax(torch.cat([self.att_x(x), self.att_y(y)], dim=-1), dim=-1)
        alpha_x = att[..., 0:1]
        alpha_y = att[..., 1:2]
        return alpha_x * x + alpha_y * y
