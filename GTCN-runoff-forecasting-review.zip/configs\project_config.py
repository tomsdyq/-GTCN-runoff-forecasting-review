﻿import os
from pathlib import Path

import torch


class ProjectConfig:
    project_root = Path(__file__).resolve().parent.parent
    single_gpu = int(os.environ.get("CUDA_DEVICE", "0"))

    if torch.cuda.is_available():
        device = torch.device(f"cuda:{single_gpu}")
        torch.cuda.set_device(device)
    else:
        device = torch.device("cpu")

    num_workers = int(os.environ.get("NUM_WORKERS", "0"))
    run_root = project_root / "runs"
    final_data_root = project_root / "final_data"
