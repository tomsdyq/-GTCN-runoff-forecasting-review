﻿# G-TCN Runoff Forecasting Model

This repository contains the source code for the manuscript:

**A Variable-as-Node Graph-Temporal Convolutional Network for Multi-Day Runoff Forecasting**

The implemented model is the variable-as-node Graph-Temporal Convolutional Network (G-TCN). Hydrometeorological variables are represented as graph nodes, a learnable adjacency matrix captures variable dependencies, a time-decay mechanism weights antecedent runoff memory, and an attention layer fuses the graph and temporal convolutional pathways.

## Repository contents

```text
configs/                  Experiment, dataset, and model configuration files
data/                     Basin ID lists used by the experiments; CAMELS data are not included
model/GCNtcnbat.py         Main G-TCN model used in the manuscript
model/tcn.py               Temporal convolutional backbone
utils/                    Training, testing, metrics, and helper utilities
pretrain_gtcn.py           Global pretraining entry point
fine_tune_gtcn.py          Basin-level fine-tuning entry point
test_gtcn_global.py        Global test entry point
test_gtcn_single.py        Basin-level test entry point
requirements.txt          Minimal Python dependencies
environment.yml           Conda environment example
```

## Data availability

The CAMELS dataset is not redistributed in this repository. Users should download the public CAMELS dataset from NCAR/UCAR and related CAMELS repositories.

Expected default local layout:

```text
GTCN-runoff-forecasting/
  data/
    camels/
      basin_dataset_public_v1p2/
        ... CAMELS files ...
```

Alternatively, set the `CAMELS_ROOT` environment variable to the CAMELS root directory.

Windows PowerShell:

```powershell
$env:CAMELS_ROOT="D:\data\basin_dataset_public_v1p2"
```

Linux/macOS:

```bash
export CAMELS_ROOT=/path/to/basin_dataset_public_v1p2
```

The default experiment uses Daymet forcing and the 673-basin list. You can change these settings with environment variables:

```bash
export CAMELS_FORCING=daymet
export CAMELS_BASIN_MARK=673
```

For the auxiliary 241-basin experiment, use:

```bash
export CAMELS_BASIN_MARK=241
```

## Installation

Using pip:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
```

Using conda:

```bash
conda env create -f environment.yml
conda activate gtcn-runoff
```

Install the PyTorch build that matches your CUDA version if the default installation is not suitable for your system.

## Running the model

Global pretraining:

```bash
python pretrain_gtcn.py
```

Global testing:

```bash
python test_gtcn_global.py
```

Basin-level fine-tuning after pretraining:

```bash
python fine_tune_gtcn.py
```

Basin-level testing:

```bash
python test_gtcn_single.py
```

Outputs are written to:

```text
runs/
final_data/
```

These directories are ignored by Git because they contain generated model checkpoints, cached data, and result files.

## Model entry point

The manuscript model is implemented in:

```text
model/GCNtcnbat.py
```

The class name is:

```python
from model.GCNtcnbat import TCN
```

Despite the class name `TCN`, this file implements the full G-TCN architecture with the graph branch, time-decay weighting, temporal convolution branch, and attention fusion.

## Reproducibility notes

The code expects 22-step input samples consisting of 15 antecedent memory days and 7 forecast-aligned positions. The six input variables consist of five meteorological variables and runoff. The main model uses `d_model=64` and four temporal convolution layers, matching the manuscript configuration.

## Citation

If you use this code, please cite the associated manuscript after publication. The `CITATION.cff` file records the current manuscript title and authorship information for traceability during peer review.
