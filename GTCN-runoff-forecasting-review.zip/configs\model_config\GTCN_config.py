﻿from ..data_shape_config import DataShapeConfig


class GTCNConfig:
    model_name = "GTCN"
    decode_mode = "NAR"
    d_model = 64
    n_layers = 4
    dropout_rate = 0.3
    emb_dropout = 0.1
    src_len = DataShapeConfig.src_len
    tgt_len = DataShapeConfig.tgt_len
    pred_len = DataShapeConfig.pred_len
    src_size = DataShapeConfig.src_size
    tgt_size = DataShapeConfig.tgt_size
    model_info = f"{model_name}_{decode_mode}_d{d_model}_layers{n_layers}"
