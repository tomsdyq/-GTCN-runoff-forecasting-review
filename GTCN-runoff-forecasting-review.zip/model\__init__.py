﻿from .GCNtcnbat import TCN
