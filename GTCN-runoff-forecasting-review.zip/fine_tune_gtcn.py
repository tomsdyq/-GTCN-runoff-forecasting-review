﻿import torch
import os
import numpy as np
import json
import importlib
from shutil import copytree

from torch.utils.data import DataLoader
from configs.project_config import ProjectConfig
from configs.data_shape_config import DataShapeConfig
from configs.run_config.fine_tune_config import FineTuneConfig
from utils.tools import SeedMethods
from utils.lr_strategies import SchedulerFactory
from model.GCNtcnbat import TCN
from utils.train_fullTCN import train_full
from data.dataset import DatasetFactory

project_root = ProjectConfig.project_root
device = ProjectConfig.device
num_workers = ProjectConfig.num_workers

past_len = DataShapeConfig.past_len
pred_len = DataShapeConfig.pred_len
src_len = DataShapeConfig.src_len
tgt_len = DataShapeConfig.tgt_len
src_size = DataShapeConfig.src_size
tgt_size = DataShapeConfig.tgt_size
use_future_fea = DataShapeConfig.use_future_fea
use_static = DataShapeConfig.use_static

used_model = FineTuneConfig.used_model
decode_mode = FineTuneConfig.decode_mode
exps_config = FineTuneConfig.exps_config
loss_func = FineTuneConfig.loss_func
n_epochs = FineTuneConfig.n_epochs
batch_size = FineTuneConfig.batch_size
learning_rate = FineTuneConfig.learning_rate
scheduler_paras = FineTuneConfig.scheduler_paras

seed = FineTuneConfig.seed
fine_tune_root = FineTuneConfig.fine_tune_root

def parse_max_nse_filename(name: str):
    """Parse checkpoint names such as '(max_nse)_107_0.8047564625740051.pkl'."""
    stem = name.replace(".pkl", "")
    parts = stem.split("_")
    if len(parts) != 3:
        raise ValueError(f"Cannot parse checkpoint filename: {name}")
    try:
        epoch = int(parts[1])
        nse = float(parts[2])
    except Exception as exc:
        raise ValueError(f"Cannot parse checkpoint filename: {name}") from exc
    return epoch, nse
if __name__ == '__main__':
    print("pid:", os.getpid())
    SeedMethods.seed_torch(seed=seed)
    if FineTuneConfig.pre_model_path is None:
        raise FileNotFoundError("No pretrained checkpoint was found under runs/new. Run pretrain_gtcn.py first.")
    fine_tune_root.mkdir(exist_ok=True)
    print(fine_tune_root)

    # 淇濆瓨閰嶇疆鏂囦欢
    configs_path = project_root / "configs"
    configs_saving = fine_tune_root / "configs"

    if configs_saving.exists():
        import shutil
        print(f"Removing existing directory: {configs_saving}")
        shutil.rmtree(configs_saving)

    copytree(configs_path, configs_saving)

    # Dataset
    DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

    # ==========================================
    #            basin-level training
    # ==========================================
    exps_num = len(exps_config)

    for idx, exp_config in enumerate(exps_config):
        tag = exp_config["tag"]
        print(f"========== Now process: {idx + 1}/{exps_num} | Basin: {tag} ==========")

        root_now = fine_tune_root / tag
        root_now.mkdir(exist_ok=True, parents=True)

        # ============================================================
        #             妫€鏌ユ槸鍚﹀凡鏈夋ā鍨?鈫?鍐冲畾鏄惁缁х画璁粌
        # ============================================================
        newest_list = list(root_now.glob("(newest)*.pkl"))
        maxnse_list = list(root_now.glob("(max_nse)*.pkl"))

        resume_training = True
        load_path = None

        if len(newest_list) > 0 and len(maxnse_list) > 0:
            newest_path = newest_list[0]
            maxnse_path = maxnse_list[0]

            # newest epoch
            newest_epoch = int(newest_path.stem.split("_")[1])

            # max_nse filename parsing
            filename = maxnse_path.stem          # e.g. "(max_nse)_107_0.8047564625740051"
            parts = filename.split("_")          # ['(max_nse)', '107', '0.8047564625740051']

            max_epoch = int(parts[2].strip())    # 107
            max_score = float(parts[3].strip())  # 0.8047564625740051

            print(f"Found models: newest={newest_epoch}, max_nse={max_score}@{max_epoch}")

            # ---- rule A: max_nse epoch 鈮?50 鈫?鍋滄璁粌 ----
            if max_epoch >= 150:
                print(f"[STOP] max_nse epoch >= 150 鈫?Skip basin {tag}")
                resume_training = False

            # ---- rule B: 杩炵画 60 epoch 鏈彁鍗?----
            elif newest_epoch - max_epoch >= 60:
                print(f"[STOP] max_nse no improvement for 60 epochs 鈫?Skip basin {tag}")
                resume_training = False

            else:
                print(f"[CONTINUE] Load newest model: {newest_path.name}")
                load_path = newest_path

        else:
            print(f"[NEW] No previous model found for basin {tag}. Start fresh.")

        if not resume_training:
            continue

        # ============================================================
        #                 鏋勫缓妯″瀷锛堜笉鍐嶅姞杞?pretrain锛?        # ============================================================
        num_chans = [64] * 3 + [64]
        pre_model = TCN(
            input_size=64,
            output_size=6,
            num_channels=num_chans,
        ).to(device)

        # 鑻ユ湁 newest锛屽垯鍔犺浇缁х画璁粌
        if load_path is not None:
            pre_model.load_state_dict(torch.load(load_path, map_location=device))

        optimizer = torch.optim.Adam(pre_model.parameters(), lr=learning_rate)
        scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
        loss_func = loss_func.to(device)

        # ============================================================
        #                    dataset per basin
        # ============================================================
        SeedMethods.seed_torch(seed=seed)

        ds_train = DS.get_instance(past_len, pred_len, "train",
                                   specific_cfg=exp_config["ft_train_config"])
        train_loader = DataLoader(ds_train, batch_size=batch_size,
                                  num_workers=num_workers, shuffle=True)

        train_x_mean, train_y_mean = ds_train.get_means()
        train_x_std, train_y_std = ds_train.get_stds()
        y_stds_dict = ds_train.y_stds_dict

        np.savetxt(root_now / "train_means.csv", np.concatenate((train_x_mean, train_y_mean), axis=0))
        np.savetxt(root_now / "train_stds.csv", np.concatenate((train_x_std, train_y_std), axis=0))

        with open(root_now / "y_stds_dict.json", "wt") as f:
            json.dump(y_stds_dict, f)

        ds_val = DS.get_instance(
            past_len, pred_len, "val",
            specific_cfg=exp_config["ft_val_config"],
            x_mean=train_x_mean, y_mean=train_y_mean,
            x_std=train_x_std, y_std=train_y_std,
            y_stds_dict=y_stds_dict
        )
        val_loader = DataLoader(ds_val, batch_size=batch_size,
                                num_workers=num_workers, shuffle=False)

        ds_test = DS.get_instance(
            past_len, pred_len, "test",
            specific_cfg=exp_config["ft_test_config"],
            x_mean=train_x_mean, y_mean=train_y_mean,
            x_std=train_x_std, y_std=train_y_std,
            y_stds_dict=y_stds_dict
        )
        test_loader = DataLoader(ds_test, batch_size=batch_size,
                                 num_workers=num_workers, shuffle=False)

        # ============================================================
        #                   start / resume training
        # ============================================================
        train_full(pre_model, decode_mode, train_loader, val_loader,
                   optimizer, scheduler, loss_func, n_epochs, device,
                   root_now)


