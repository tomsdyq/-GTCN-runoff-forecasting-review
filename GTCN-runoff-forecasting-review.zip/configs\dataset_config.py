﻿import os
from pathlib import Path

import pandas as pd


class DatasetConfig:
    """Dataset configuration for CAMELS experiments.

    Set CAMELS_ROOT to the root directory of the CAMELS public dataset, for example:
    Windows PowerShell: $env:CAMELS_ROOT="D:\\data\\basin_dataset_public_v1p2"
    Linux/macOS:        export CAMELS_ROOT=/path/to/basin_dataset_public_v1p2
    """

    project_root = Path(__file__).resolve().parent.parent
    camels_root = Path(
        os.environ.get(
            "CAMELS_ROOT",
            project_root / "data" / "camels" / "basin_dataset_public_v1p2",
        )
    )

    forcing_type = os.environ.get("CAMELS_FORCING", "daymet")
    basin_mark = os.environ.get("CAMELS_BASIN_MARK", "673")
    basins_file = project_root / "data" / f"{basin_mark}basins_list.txt"
    global_basins_list = pd.read_csv(basins_file, header=None, dtype=str)[0].values.tolist()

    train_start = pd.to_datetime("1980-10-01", format="%Y-%m-%d")
    train_end = pd.to_datetime("1995-09-30", format="%Y-%m-%d")
    val_start = pd.to_datetime("1995-10-01", format="%Y-%m-%d")
    val_end = pd.to_datetime("2000-09-30", format="%Y-%m-%d")
    test_start = pd.to_datetime("2000-10-01", format="%Y-%m-%d")
    test_end = pd.to_datetime("2014-09-30", format="%Y-%m-%d")

    dataset_info = (
        f"{forcing_type}{basin_mark}_{train_start.year}~{train_end.year}"
        f"#{val_start.year}~{val_end.year}#{test_start.year}~{test_end.year}"
    )
