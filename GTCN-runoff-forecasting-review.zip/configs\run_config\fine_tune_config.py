﻿import torch.nn as nn
import importlib

from ..project_config import ProjectConfig
from ..dataset_config import DatasetConfig
from utils import nseloss


class FineTuneLearningConfig:
    loss_type = "MSE"
    loss_functions = {"MSE": nn.MSELoss(), "NSELoss": nseloss.NSELoss()}
    loss_func = loss_functions[loss_type]

    scale_factor = 1
    n_epochs = 200
    batch_size = 512 // scale_factor
    learning_rate = 0.001 / scale_factor
    scheduler_paras = {"scheduler_type": "warm_up", "warm_up_epochs": n_epochs * 0.25, "decay_rate": 0.99}
    learning_config_info = f"{loss_type}_n{n_epochs}_bs{batch_size}_lr{learning_rate}_{scheduler_paras['scheduler_type']}"


class FineTuneConfig(FineTuneLearningConfig):
    seed = None
    used_model = "GTCN"

    used_model_config = importlib.import_module(f"configs.model_config.{used_model}_config")
    used_ModelConfig = getattr(used_model_config, f"{used_model}Config")
    decode_mode = used_ModelConfig.decode_mode

    exps_config = []
    for basin in DatasetConfig.global_basins_list:
        exp_config = {
            "tag": basin,
            "ft_train_config": {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": [basin],
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.train_start,
                "end_date": DatasetConfig.train_end,
                "final_data_path": None,
            },
            "ft_val_config": {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": [basin],
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.val_start,
                "end_date": DatasetConfig.val_end,
                "final_data_path": None,
            },
            "ft_test_config": {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": [basin],
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.test_start,
                "end_date": DatasetConfig.test_end,
                "final_data_path": None,
            },
        }
        exps_config.append(exp_config)

    pre_saving_root = ProjectConfig.run_root / "new"
    pre_model_candidates = list(pre_saving_root.glob("(max_nse)*.pkl"))
    pre_model_path = pre_model_candidates[0] if pre_model_candidates else None
    fine_tune_root = pre_saving_root / "fine_tune"
